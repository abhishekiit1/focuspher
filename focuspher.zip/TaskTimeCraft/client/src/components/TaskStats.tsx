import { Task } from '@shared/schema';

interface TaskStatsProps {
  tasks: Task[];
}

export const TaskStats = ({ tasks }: TaskStatsProps) => {
  const completed = tasks.filter(task => task.completed).length;
  const pending = tasks.filter(task => !task.completed).length;
  const total = tasks.length;
  const productivity = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-6">
      <div className="glass-effect rounded-xl p-6 text-center">
        <div className="text-3xl font-bold text-purple-400 mb-2">{completed}</div>
        <div className="text-slate-400">Completed</div>
      </div>
      <div className="glass-effect rounded-xl p-6 text-center">
        <div className="text-3xl font-bold text-blue-400 mb-2">{pending}</div>
        <div className="text-slate-400">Pending</div>
      </div>
      <div className="glass-effect rounded-xl p-6 text-center">
        <div className="text-3xl font-bold text-emerald-400 mb-2">{productivity}%</div>
        <div className="text-slate-400">Productivity</div>
      </div>
    </div>
  );
};
