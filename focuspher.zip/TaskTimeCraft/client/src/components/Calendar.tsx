import { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { Task } from '@shared/schema';

interface CalendarProps {
  tasks: Task[];
  onDateSelect?: (date: Date) => void;
}

export const Calendar = ({ tasks = [], onDateSelect }: CalendarProps) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date();

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const getTasksForDate = (date: Date) => {
    return tasks.filter(task => {
      const taskDate = task.dueDate || task.createdAt;
      return taskDate.toDateString() === date.toDateString();
    });
  };

  const isPastDate = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    date.setHours(0, 0, 0, 0);
    return date < today;
  };

  const isFutureDate = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    date.setHours(0, 0, 0, 0);
    return date > today;
  };

  const handleDateClick = (day: number) => {
    const clickedDate = new Date(year, month, day);
    setSelectedDate(clickedDate);
    
    // Allow selection of any date (past dates for viewing history, future for scheduling)
    if (onDateSelect) {
      onDateSelect(clickedDate);
    }
  };

  const renderCalendarDays = () => {
    const days = [];
    
    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="text-center py-2 text-slate-600"></div>);
    }
    
    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const currentDay = new Date(year, month, day);
      const isToday = today.getDate() === day && 
                     today.getMonth() === month && 
                     today.getFullYear() === year;
      const isPast = isPastDate(currentDay);
      const isFuture = isFutureDate(currentDay);
      const isSelected = selectedDate && 
                        selectedDate.getDate() === day && 
                        selectedDate.getMonth() === month && 
                        selectedDate.getFullYear() === year;
      const dayTasks = getTasksForDate(currentDay);
      const hasCompletedTasks = dayTasks.some(task => task.completed);
      
      let dayClass = 'text-center py-1 sm:py-2 cursor-pointer relative transition-all duration-200 text-xs sm:text-sm ';
      
      if (isToday) {
        dayClass += 'bg-gradient-to-r from-purple-500 to-teal-500 text-white rounded font-semibold ';
      } else if (isSelected) {
        dayClass += 'bg-purple-500/30 text-purple-200 rounded ';
      } else if (isPast) {
        dayClass += 'text-slate-500 opacity-60 ';
      } else if (isFuture) {
        dayClass += 'hover:bg-white/10 rounded text-slate-200 ';
      } else {
        dayClass += 'hover:bg-white/10 rounded text-slate-200 ';
      }
      
      days.push(
        <div 
          key={day} 
          className={dayClass}
          onClick={() => handleDateClick(day)}
        >
          <div>{day}</div>
          {/* Task indicators */}
          {dayTasks.length > 0 && (
            <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 flex gap-1">
              {hasCompletedTasks && (
                <div className="w-1.5 h-1.5 bg-green-400 rounded-full"></div>
              )}
              {dayTasks.some(task => !task.completed) && (
                <div className="w-1.5 h-1.5 bg-orange-400 rounded-full"></div>
              )}
            </div>
          )}
        </div>
      );
    }
    
    return days;
  };

  return (
    <div className="glass-effect rounded-xl p-4">
      <h3 className="text-lg font-medium mb-4 text-slate-200">Calendar</h3>
      <div className="mb-4 flex justify-between items-center">
        <button 
          onClick={prevMonth}
          className="text-slate-400 hover:text-white transition-colors duration-200 p-1 hover:bg-white/10 rounded"
        >
          <ChevronLeft size={16} />
        </button>
        <span className="font-medium text-slate-200">
          {currentDate.toLocaleDateString('en-US', { 
            month: 'long', 
            year: 'numeric' 
          })}
        </span>
        <button 
          onClick={nextMonth}
          className="text-slate-400 hover:text-white transition-colors duration-200 p-1 hover:bg-white/10 rounded"
        >
          <ChevronRight size={16} />
        </button>
      </div>
      
      {/* Calendar Header */}
      <div className="calendar-grid text-xs text-slate-400 mb-2">
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, index) => (
          <div key={index} className="text-center py-1">{day}</div>
        ))}
      </div>
      
      {/* Calendar Days */}
      <div className="calendar-grid text-sm">
        {renderCalendarDays()}
      </div>
    </div>
  );
};
