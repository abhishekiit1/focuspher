import { useState, useEffect } from 'react';

export const AnalogClock = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const hours = time.getHours() % 12;
  const minutes = time.getMinutes();
  const seconds = time.getSeconds();

  const hourAngle = (hours * 30) + (minutes * 0.5);
  const minuteAngle = minutes * 6;
  const secondAngle = seconds * 6;

  return (
    <div className="mb-8">
      <h3 className="text-lg font-medium mb-4 text-slate-200">Current Time</h3>
      <div className="clock-face rounded-full w-48 h-48 mx-auto relative flex items-center justify-center">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-44 h-44 relative">
            {/* Clock markers */}
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-1 h-6 bg-white/60 rounded"></div>
            <div className="absolute right-0 top-1/2 transform -translate-y-1/2 h-1 w-6 bg-white/60 rounded"></div>
            <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-6 bg-white/60 rounded"></div>
            <div className="absolute left-0 top-1/2 transform -translate-y-1/2 h-1 w-6 bg-white/60 rounded"></div>
            
            {/* Hour hand */}
            <div 
              className="clock-hand absolute top-1/2 left-1/2 w-12 h-1 rounded-full transform -translate-y-1/2 origin-left transition-transform duration-1000"
              style={{ transform: `translateY(-50%) rotate(${hourAngle}deg)` }}
            ></div>
            
            {/* Minute hand */}
            <div 
              className="clock-hand absolute top-1/2 left-1/2 w-16 h-0.5 rounded-full transform -translate-y-1/2 origin-left transition-transform duration-1000"
              style={{ transform: `translateY(-50%) rotate(${minuteAngle}deg)` }}
            ></div>
            
            {/* Second hand */}
            <div 
              className="absolute top-1/2 left-1/2 w-18 h-px bg-red-400 transform -translate-y-1/2 origin-left transition-transform duration-75"
              style={{ transform: `translateY(-50%) rotate(${secondAngle}deg)` }}
            ></div>
            
            {/* Center dot */}
            <div className="absolute top-1/2 left-1/2 w-3 h-3 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
          </div>
        </div>
      </div>
      <div className="text-center mt-4">
        <div className="text-slate-300 font-mono text-lg">
          {time.toLocaleTimeString()}
        </div>
        <div className="text-slate-400 text-sm mt-1">
          {time.toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </div>
    </div>
  );
};
