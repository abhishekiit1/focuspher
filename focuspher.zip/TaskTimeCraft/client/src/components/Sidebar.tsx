import { X, Menu } from 'lucide-react';
import { AnalogClock } from './AnalogClock';
import { Calendar } from './Calendar';
import { ProgressRing } from './ProgressRing';
import { StreakChart } from './StreakChart';
import { Task } from '@shared/schema';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  tasks: Task[];
  onDateSelect?: (date: Date) => void;
}

export const Sidebar = ({ isOpen, onToggle, tasks = [], onDateSelect }: SidebarProps) => {
  const completedTasks = tasks.filter(task => task.completed).length;
  const totalTasks = tasks.length;
  const progressPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  
  return (
    <>
      {/* Sidebar Overlay */}
      <div 
        className={`fixed inset-0 bg-black/50 z-30 transition-opacity duration-300 ${
          isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onToggle}
      ></div>
      
      {/* Sidebar */}
      <div className={`sidebar sidebar-glass w-72 sm:w-80 h-screen fixed left-0 top-0 p-4 sm:p-6 overflow-y-auto z-40 transform transition-transform duration-300 ease-in-out ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        {/* Close Button */}
        <button 
          className="absolute top-4 right-4 text-white/70 hover:text-white transition-colors"
          onClick={onToggle}
        >
          <X size={20} />
        </button>
        
        {/* App Title */}
        <div className="mb-6 sm:mb-8 text-center">
          <h1 className="text-xl sm:text-2xl font-semibold bg-gradient-to-r from-purple-400 to-teal-400 bg-clip-text text-transparent">
            Focuspher
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">Clear your mind. Conquer your list.</p>
        </div>
        
        {/* Analog Clock */}
        <AnalogClock />
        
        {/* Progress Ring */}
        <div className="mb-8 flex justify-center">
          <ProgressRing progress={progressPercentage} />
        </div>
        
        {/* Calendar */}
        <div className="mb-8">
          <Calendar tasks={tasks || []} onDateSelect={onDateSelect} />
        </div>
        
        {/* Streak Chart */}
        <StreakChart tasks={tasks || []} />
      </div>
    </>
  );
};
