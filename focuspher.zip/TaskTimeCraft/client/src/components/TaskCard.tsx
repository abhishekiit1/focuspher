import { useState } from 'react';
import { Trash2, Clock, CheckCircle2, Circle, Edit3, ChevronDown, ChevronUp } from 'lucide-react';
import { Task } from '@shared/schema';
import { motion } from 'framer-motion';

interface TaskCardProps {
  task: Task;
  onToggle: (id: string, completed: boolean) => void;
  onDelete: (id: string) => void;
  onEdit?: (task: Task) => void;
}

export const TaskCard = ({ task, onToggle, onDelete, onEdit }: TaskCardProps) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  const handleToggle = () => {
    onToggle(task.id, !task.completed);
  };

  const handleDelete = async () => {
    if (confirm('Are you sure you want to delete this task?')) {
      setIsDeleting(true);
      try {
        await onDelete(task.id);
      } catch (error) {
        setIsDeleting(false);
      }
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-yellow-400';
      case 'low': return 'text-green-400';
      default: return 'text-slate-400';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${diffInHours} hour${diffInHours > 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.2 }}
      className="glass-effect rounded-xl p-3 sm:p-4 hover:bg-white/5 transition-all duration-300 group"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3 flex-1 min-w-0">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleToggle}
            className="flex-shrink-0 transition-colors duration-200"
          >
            {task.completed ? (
              <CheckCircle2 className="w-5 h-5 text-green-400" />
            ) : (
              <Circle className="w-5 h-5 text-slate-400 hover:text-blue-400" />
            )}
          </motion.button>

          <div className="flex-1 min-w-0">
            <p className={`text-sm sm:text-base font-medium transition-all duration-200 ${
              task.completed 
                ? 'text-slate-500 line-through' 
                : 'text-slate-200'
            }`}>
              {task.description}
            </p>
            
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 mt-1">
              <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium self-start ${
                task.priority === 'high' 
                  ? 'bg-red-500/20 text-red-300' 
                  : task.priority === 'medium'
                  ? 'bg-yellow-500/20 text-yellow-300'
                  : 'bg-green-500/20 text-green-300'
              }`}>
                {task.priority}
              </span>
              
              <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 text-xs text-slate-400">
                <div className="flex items-center">
                  <Clock className="w-3 h-3 mr-1 flex-shrink-0" />
                  <span className="truncate">{formatTimeAgo(task.createdAt)}</span>
                </div>
                {task.dueDate && (
                  <div className={`flex items-center ${
                    task.dueDate < new Date() && !task.completed ? 'text-red-400' : 
                    task.dueDate.toDateString() === new Date().toDateString() ? 'text-yellow-400' : 'text-slate-400'
                  }`}>
                    <span className="mr-1 flex-shrink-0">📅</span>
                    <span className="truncate">
                      Due {task.dueDate < new Date() && !task.completed ? 'overdue' : 
                           task.dueDate.toDateString() === new Date().toDateString() ? 'today' : 
                           task.dueDate.toLocaleDateString()}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {task.details && (
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowDetails(!showDetails)}
              className="flex-shrink-0 p-2 text-slate-400 hover:text-blue-400 transition-colors duration-200"
            >
              {showDetails ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </motion.button>
          )}
          
          {onEdit && (
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => onEdit(task)}
              className="flex-shrink-0 p-2 text-slate-400 hover:text-blue-400 transition-colors duration-200 opacity-0 group-hover:opacity-100"
            >
              <Edit3 className="w-4 h-4" />
            </motion.button>
          )}

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleDelete}
            disabled={isDeleting}
            className="flex-shrink-0 p-2 text-slate-400 hover:text-red-400 transition-colors duration-200 disabled:opacity-50 opacity-0 group-hover:opacity-100"
          >
            <Trash2 className="w-4 h-4" />
          </motion.button>
        </div>
      </div>

      {/* Task Details */}
      {showDetails && task.details && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="mt-3 pt-3 border-t border-slate-700/50"
        >
          <p className="text-sm text-slate-300 leading-relaxed">
            {task.details}
          </p>
        </motion.div>
      )}
    </motion.div>
  );
};
