import { useState } from 'react';
import { Task } from '@shared/schema';

interface StreakChartProps {
  tasks: Task[];
}

export const StreakChart = ({ tasks = [] }: StreakChartProps) => {
  const [hoveredDay, setHoveredDay] = useState<string | null>(null);

  // Generate the last 12 weeks of days (84 days)
  const generateDays = () => {
    const days = [];
    const today = new Date();
    
    for (let i = 83; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      days.push(date);
    }
    
    return days;
  };

  // Get task count for a specific date
  const getTaskCountForDate = (date: Date) => {
    const dateStr = date.toDateString();
    return tasks.filter(task => {
      const taskDate = task.completedAt || task.createdAt;
      return task.completed && taskDate.toDateString() === dateStr;
    }).length;
  };

  // Get intensity level based on task count
  const getIntensity = (count: number) => {
    if (count === 0) return 0;
    if (count <= 1) return 1;
    if (count <= 2) return 2;
    if (count <= 4) return 3;
    if (count <= 6) return 4;
    return 5;
  };

  const days = generateDays();
  const weeks = [];
  
  // Group days into weeks
  for (let i = 0; i < days.length; i += 7) {
    weeks.push(days.slice(i, i + 7));
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <div className="glass-effect rounded-xl p-6">
      <h3 className="text-lg font-medium mb-4 text-slate-200">Activity Streak</h3>
      
      <div className="flex flex-col gap-1">
        {/* Month labels */}
        <div className="flex justify-between text-xs text-slate-400 mb-2">
          {['3 months ago', '2 months ago', '1 month ago', 'Now'].map((label, i) => (
            <span key={i}>{label}</span>
          ))}
        </div>
        
        {/* Streak grid */}
        <div className="flex gap-1">
          {weeks.map((week, weekIndex) => (
            <div key={weekIndex} className="flex flex-col gap-1">
              {week.map((day, dayIndex) => {
                const taskCount = getTaskCountForDate(day);
                const intensity = getIntensity(taskCount);
                const dayKey = day.toISOString().split('T')[0];
                
                return (
                  <div
                    key={dayIndex}
                    className={`w-3 h-3 streak-day streak-intensity-${intensity} cursor-pointer`}
                    onMouseEnter={() => setHoveredDay(dayKey)}
                    onMouseLeave={() => setHoveredDay(null)}
                    title={`${formatDate(day)}: ${taskCount} tasks completed`}
                  />
                );
              })}
            </div>
          ))}
        </div>
        
        {/* Legend */}
        <div className="flex items-center justify-between mt-3 text-xs text-slate-400">
          <span>Less</span>
          <div className="flex gap-1">
            {[0, 1, 2, 3, 4, 5].map(level => (
              <div
                key={level}
                className={`w-3 h-3 streak-day streak-intensity-${level}`}
              />
            ))}
          </div>
          <span>More</span>
        </div>
        
        {/* Hover tooltip */}
        {hoveredDay && (
          <div className="mt-2 text-sm text-slate-300">
            {(() => {
              const date = new Date(hoveredDay);
              const count = getTaskCountForDate(date);
              return `${formatDate(date)}: ${count} task${count !== 1 ? 's' : ''} completed`;
            })()}
          </div>
        )}
      </div>
    </div>
  );
};