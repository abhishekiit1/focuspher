import { useState } from 'react';
import { Plus, Menu } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sidebar } from '@/components/Sidebar';
import { TaskCard } from '@/components/TaskCard';
import { TaskStats } from '@/components/TaskStats';
import { ProgressBar } from '@/components/ProgressBar';
import { useTasks } from '@/hooks/useTasks';
import { useToast } from '@/hooks/use-toast';
import { Task } from '@shared/schema';

type FilterType = 'all' | 'pending' | 'completed';

export default function Tasks() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [newTaskText, setNewTaskText] = useState('');
  const [newTaskDetails, setNewTaskDetails] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [showDateTasks, setShowDateTasks] = useState(false);
  
  const { tasks, loading, error, addTask, toggleTask, deleteTask, updateTask } = useTasks();
  const { toast } = useToast();

  const filteredTasks = tasks.filter(task => {
    // First filter by date if showing date-specific tasks
    let dateFiltered = tasks;
    if (showDateTasks) {
      const selectedDateStr = selectedDate.toDateString();
      dateFiltered = tasks.filter(task => {
        if (task.dueDate) {
          return task.dueDate.toDateString() === selectedDateStr;
        }
        // If no due date, show task on creation date
        return task.createdAt.toDateString() === selectedDateStr;
      });
    }
    
    // Then apply status filter
    return dateFiltered.filter(task => {
      switch (filter) {
        case 'pending': return !task.completed;
        case 'completed': return task.completed;
        default: return true;
      }
    });
  });

  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newTaskText.trim()) {
      toast({
        title: "Error",
        description: "Please enter a task description",
        variant: "destructive",
      });
      return;
    }

    try {
      const taskData = {
        description: newTaskText.trim(),
        details: newTaskDetails.trim() || undefined,
        completed: false,
        priority,
        dueDate: showDateTasks && selectedDate > new Date() ? selectedDate : undefined,
      };
      
      await addTask(taskData);
      
      setNewTaskText('');
      setNewTaskDetails('');
      toast({
        title: "Success",
        description: "Task added successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add task",
        variant: "destructive",
      });
    }
  };

  const handleEditTask = (task: Task) => {
    // Prevent editing tasks that are due in the past
    if (task.dueDate && task.dueDate < new Date() && !task.completed) {
      toast({
        title: "Cannot Edit",
        description: "Past due tasks cannot be edited. Please complete or delete them.",
        variant: "destructive",
      });
      return;
    }
    
    setEditingTask(task);
    setNewTaskText(task.description);
    setNewTaskDetails(task.details || '');
    setPriority(task.priority);
  };

  const handleUpdateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTask || !newTaskText.trim()) return;

    try {
      await updateTask(editingTask.id, {
        description: newTaskText.trim(),
        details: newTaskDetails.trim() || undefined,
        priority,
      });
      
      setEditingTask(null);
      setNewTaskText('');
      setNewTaskDetails('');
      setPriority('medium');
      toast({
        title: "Success",
        description: "Task updated successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    }
  };

  const cancelEdit = () => {
    setEditingTask(null);
    setNewTaskText('');
    setNewTaskDetails('');
    setPriority('medium');
  };

  const handleToggleTask = async (id: string, completed: boolean) => {
    try {
      await toggleTask(id, completed);
      toast({
        title: "Success",
        description: completed ? "Task completed!" : "Task marked as pending",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    }
  };

  const handleDeleteTask = async (id: string) => {
    try {
      await deleteTask(id);
      toast({
        title: "Success",
        description: "Task deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete task",
        variant: "destructive",
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAddTask(e);
    }
  };

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="glass-effect rounded-xl p-8 text-center">
          <h2 className="text-2xl font-semibold text-red-400 mb-4">Connection Error</h2>
          <p className="text-slate-300 mb-4">{error}</p>
          <p className="text-slate-400 text-sm">Please check your Firebase configuration</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex overflow-hidden">
      <Sidebar 
        isOpen={sidebarOpen} 
        onToggle={() => setSidebarOpen(!sidebarOpen)} 
        tasks={tasks}
        onDateSelect={(date) => {
          setSelectedDate(date);
          setShowDateTasks(true);
          setFilter('all'); // Reset filter when switching dates
        }}
      />
      
      <div className="flex-1 flex flex-col">
        {/* Sidebar Toggle Button */}
        <button 
          className="fixed top-4 left-4 z-50 glass-effect rounded-lg p-2 md:p-3 text-white hover:bg-white/10 transition-all duration-300"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          <Menu size={18} className="md:w-5 md:h-5" />
        </button>

        <div className="flex-1 overflow-auto p-3 pl-14 pt-3 sm:p-4 sm:pl-16 md:p-6 md:pl-20 lg:pl-6">
        {/* Progress Bar */}
        {!loading && tasks.length > 0 && (
          <div className="mb-4 md:mb-6">
            <div className="flex items-center justify-between mb-2 md:mb-3">
              <span className="text-xs sm:text-sm text-slate-400">Overall Progress</span>
              <span className="text-xs sm:text-sm text-slate-300">
                {tasks.filter(t => t.completed).length} of {tasks.length} completed
              </span>
            </div>
            <ProgressBar 
              progress={tasks.length > 0 ? (tasks.filter(t => t.completed).length / tasks.length) * 100 : 0}
            />
          </div>
        )}

        {/* Header */}
        <div className="mb-4 md:mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 md:gap-4 mb-4 md:mb-6">
            <div>
              <h2 className="text-xl sm:text-2xl md:text-3xl font-semibold text-slate-100 mb-1 md:mb-2 leading-tight">
                {showDateTasks ? (
                  <>
                    <span className="hidden sm:inline">Tasks for {selectedDate.toLocaleDateString()}</span>
                    <span className="sm:hidden">Tasks for {selectedDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                  </>
                ) : 'My Tasks'}
              </h2>
              <p className="text-sm md:text-base text-slate-400">
                {showDateTasks 
                  ? `${selectedDate.toDateString() === new Date().toDateString() ? 'Today' : selectedDate.toDateString()}`
                  : 'Stay organized and productive'
                }
              </p>
            </div>
            <div className="text-right flex-shrink-0">
              <div className="text-xl md:text-2xl font-semibold text-purple-400">
                {showDateTasks ? filteredTasks.length : tasks.length}
              </div>
              <div className="text-xs md:text-sm text-slate-400">
                {showDateTasks ? 'Tasks for Date' : 'Total Tasks'}
              </div>
            </div>
          </div>
          
          {/* Date View Toggle */}
          <div className="flex flex-wrap gap-1 md:gap-2 mb-3 md:mb-4">
            <button
              onClick={() => {
                setShowDateTasks(false);
                setSelectedDate(new Date());
              }}
              className={`px-3 py-1.5 md:px-4 md:py-2 rounded-lg text-sm md:text-base font-medium transition-all duration-300 ${
                !showDateTasks
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                  : 'text-slate-400 hover:bg-white/10'
              }`}
            >
              All Tasks
            </button>
            <button
              onClick={() => {
                setSelectedDate(new Date());
                setShowDateTasks(true);
              }}
              className={`px-3 py-1.5 md:px-4 md:py-2 rounded-lg text-sm md:text-base font-medium transition-all duration-300 ${
                showDateTasks && selectedDate.toDateString() === new Date().toDateString()
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                  : 'text-slate-400 hover:bg-white/10'
              }`}
            >
              Today
            </button>
            {showDateTasks && selectedDate.toDateString() !== new Date().toDateString() && (
              <div className="flex items-center gap-2 px-2 md:px-3 py-1.5 md:py-2 bg-slate-700/50 rounded-lg text-slate-300 text-xs md:text-sm">
                <span className="hidden sm:inline">Viewing: {selectedDate.toLocaleDateString()}</span>
                <span className="sm:hidden">{selectedDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                <button
                  onClick={() => setShowDateTasks(false)}
                  className="text-slate-400 hover:text-white ml-1 md:ml-2"
                >
                  ×
                </button>
              </div>
            )}
          </div>
          
          {/* Add Task Form */}
          <div className="glass-effect rounded-xl p-4 md:p-6 mb-4 md:mb-8">
            <h3 className="text-base md:text-lg font-medium text-slate-200 mb-3 md:mb-4">
              {editingTask ? 'Edit Task' : showDateTasks && selectedDate > new Date() ? (
                <>
                  <span className="hidden sm:inline">Schedule Task for {selectedDate.toLocaleDateString()}</span>
                  <span className="sm:hidden">Schedule for {selectedDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                </>
              ) : 'Add New Task'}
            </h3>
            <form onSubmit={editingTask ? handleUpdateTask : handleAddTask} className="space-y-3 md:space-y-4">
              <div className="space-y-3">
                <input 
                  type="text" 
                  value={newTaskText}
                  onChange={(e) => setNewTaskText(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Add a new task..." 
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 md:px-4 md:py-3 text-sm md:text-base text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent backdrop-blur-sm transition-all duration-300"
                />
                <textarea 
                  value={newTaskDetails}
                  onChange={(e) => setNewTaskDetails(e.target.value)}
                  placeholder="Add task details (optional)..." 
                  rows={2}
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 md:px-4 md:py-3 text-sm md:text-base text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent backdrop-blur-sm transition-all duration-300 resize-none md:rows-3"
                />
                <div className="flex flex-col gap-3 sm:flex-row">
                  <div className="flex flex-col gap-1 flex-1 sm:flex-initial">
                    <label className="text-xs text-slate-400">Priority</label>
                    <select
                      value={priority}
                      onChange={(e) => setPriority(e.target.value as 'low' | 'medium' | 'high')}
                      className="bg-white/10 border border-white/20 rounded-lg px-3 py-2 md:px-4 md:py-3 text-sm md:text-base text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent backdrop-blur-sm transition-all duration-300"
                    >
                      <option value="low" className="bg-slate-800">Low</option>
                      <option value="medium" className="bg-slate-800">Medium</option>
                      <option value="high" className="bg-slate-800">High</option>
                    </select>
                  </div>
                  <div className="flex gap-2 flex-1 sm:flex-initial">
                    <button 
                      type="submit"
                      className="flex-1 sm:flex-initial add-task-btn px-4 py-2 md:px-6 md:py-3 rounded-lg text-white font-medium shadow-lg hover:shadow-xl transition-all duration-300 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-sm md:text-base"
                    >
                      <Plus size={16} className="mr-1 md:mr-2 inline md:w-5 md:h-5" />
                      <span className="hidden sm:inline">{editingTask ? 'Update Task' : 'Add Task'}</span>
                      <span className="sm:hidden">{editingTask ? 'Update' : 'Add'}</span>
                    </button>
                    {editingTask && (
                      <button 
                        type="button"
                        onClick={cancelEdit}
                        className="px-4 py-2 md:px-6 md:py-3 rounded-lg text-slate-300 font-medium border border-slate-600 hover:bg-slate-700 transition-all duration-300 text-sm md:text-base"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>

        {/* Task Filters */}
        <div className="flex flex-wrap gap-1 md:gap-2 mb-4 md:mb-6">
          {(['all', 'pending', 'completed'] as FilterType[]).map((filterType) => (
            <button
              key={filterType}
              onClick={() => setFilter(filterType)}
              className={`px-3 py-1.5 md:px-4 md:py-2 rounded-lg text-sm md:text-base font-medium transition-all duration-300 capitalize ${
                filter === filterType
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                  : 'text-slate-400 hover:bg-white/10'
              }`}
            >
              <span className="hidden sm:inline">{filterType} Tasks</span>
              <span className="sm:hidden capitalize">{filterType}</span>
            </button>
          ))}
        </div>

        {/* Tasks List */}
        <div className="space-y-3 md:space-y-4">
          {loading ? (
            <div className="space-y-3 md:space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="glass-effect rounded-xl p-4 md:p-6 animate-pulse">
                  <div className="flex items-center gap-3 md:gap-4">
                    <div className="w-4 h-4 md:w-5 md:h-5 bg-slate-600 rounded"></div>
                    <div className="flex-1">
                      <div className="h-3 md:h-4 bg-slate-600 rounded w-3/4 mb-1 md:mb-2"></div>
                      <div className="h-2 md:h-3 bg-slate-700 rounded w-1/2"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredTasks.length === 0 ? (
            <div className="glass-effect rounded-xl p-6 md:p-12 text-center">
              <div className="text-4xl md:text-6xl text-slate-600 mb-3 md:mb-4">📝</div>
              <h3 className="text-lg md:text-xl font-medium text-slate-300 mb-2">
                {showDateTasks 
                  ? `No tasks for ${selectedDate.toLocaleDateString()}` 
                  : filter === 'all' ? 'No tasks yet' : `No ${filter} tasks`
                }
              </h3>
              <p className="text-sm md:text-base text-slate-400">
                {showDateTasks 
                  ? selectedDate > new Date() 
                    ? 'Schedule a task for this date using the form above'
                    : 'No tasks were scheduled for this date'
                  : filter === 'all' 
                    ? 'Add your first task to get started!' 
                    : `You have no ${filter} tasks.`
                }
              </p>
            </div>
          ) : (
            <AnimatePresence>
              {filteredTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onToggle={handleToggleTask}
                  onDelete={handleDeleteTask}
                  onEdit={handleEditTask}
                />
              ))}
            </AnimatePresence>
          )}
        </div>

        {/* Stats */}
        <TaskStats tasks={tasks} />
        </div>
      </div>
    </div>
  );
}
