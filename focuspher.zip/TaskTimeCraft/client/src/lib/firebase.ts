import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAb2FkQUyqZlK9nXSTRVGOIDC-r-oIPsgI",
  authDomain: "task-manager-4434d.firebaseapp.com",
  projectId: "task-manager-4434d",
  storageBucket: "task-manager-4434d.firebasestorage.app",
  messagingSenderId: "204062809009",
  appId: "1:204062809009:web:ef0ee1a43b24085d867b90",
  measurementId: "G-DT2V2NQKN5"
};

// Initialize Firebase app only if it doesn't exist
export const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const db = getFirestore(app);

// Add debugging to check if Firebase is properly initialized
console.log('Firebase app initialized:', app.name);
console.log('Firestore initialized:', db.app.name);
