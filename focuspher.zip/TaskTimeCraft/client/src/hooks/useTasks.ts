import { useState, useEffect } from 'react';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  onSnapshot, 
  orderBy, 
  query,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Task, InsertTask } from '@shared/schema';

export const useTasks = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const tasksQuery = query(
      collection(db, 'tasks'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(
      tasksQuery,
      (snapshot) => {
        try {
          console.log('Firestore snapshot received, docs count:', snapshot.docs.length);
          const tasksData = snapshot.docs.map(doc => {
            const data = doc.data();
            console.log('Processing task doc:', doc.id, data);
            return {
              id: doc.id,
              description: data.description,
              details: data.details,
              completed: data.completed,
              priority: data.priority || 'medium',
              createdAt: data.createdAt?.toDate() || new Date(),
              completedAt: data.completedAt?.toDate(),
              dueDate: data.dueDate?.toDate(),
            } as Task;
          });
          setTasks(tasksData);
          setLoading(false);
          setError(null);
          console.log('Tasks loaded successfully:', tasksData.length);
        } catch (err) {
          console.error('Error processing tasks:', err);
          setError('Failed to load tasks');
          setLoading(false);
        }
      },
      (err) => {
        console.error('Firestore snapshot error:', err);
        setError(`Failed to connect to database: ${err.message}`);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const addTask = async (taskData: InsertTask) => {
    try {
      console.log('Adding task:', taskData);
      
      // Prepare the data for Firestore
      const firestoreData: any = {
        description: taskData.description,
        completed: taskData.completed || false,
        priority: taskData.priority || 'medium',
        createdAt: serverTimestamp(),
      };
      
      // Only add optional fields if they exist
      if (taskData.details) {
        firestoreData.details = taskData.details;
      }
      
      if (taskData.dueDate) {
        firestoreData.dueDate = taskData.dueDate;
      }
      
      const docRef = await addDoc(collection(db, 'tasks'), firestoreData);
      console.log('Task added successfully with ID:', docRef.id);
    } catch (err) {
      console.error('Error adding task:', err);
      throw new Error(`Failed to add task: ${err.message}`);
    }
  };

  const updateTask = async (id: string, updates: Partial<Task>) => {
    try {
      const taskRef = doc(db, 'tasks', id);
      const updateData: any = {};
      
      // Only include fields that are actually being updated
      if (updates.description !== undefined) updateData.description = updates.description;
      if (updates.details !== undefined) updateData.details = updates.details;
      if (updates.priority !== undefined) updateData.priority = updates.priority;
      if (updates.dueDate !== undefined) updateData.dueDate = updates.dueDate;
      
      if (updates.completed !== undefined) {
        updateData.completed = updates.completed;
        updateData.completedAt = updates.completed ? serverTimestamp() : null;
      }
      
      await updateDoc(taskRef, updateData);
    } catch (err) {
      console.error('Error updating task:', err);
      throw new Error('Failed to update task');
    }
  };

  const deleteTask = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'tasks', id));
    } catch (err) {
      throw new Error('Failed to delete task');
    }
  };

  const toggleTask = async (id: string, completed: boolean) => {
    await updateTask(id, { completed });
  };

  return {
    tasks,
    loading,
    error,
    addTask,
    updateTask,
    deleteTask,
    toggleTask,
  };
};
