import { z } from "zod";
import { pgTable, serial, text, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

// Database schema
export const priorityEnum = pgEnum("priority", ["low", "medium", "high"]);

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  description: text("description").notNull(),
  details: text("details"),
  completed: boolean("completed").default(false).notNull(),
  priority: priorityEnum("priority").default("medium").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  dueDate: timestamp("due_date"),
});

// Zod schemas
export const taskSchema = z.object({
  id: z.string(),
  description: z.string().min(1, "Task description is required"),
  details: z.string().optional(),
  completed: z.boolean(),
  createdAt: z.date(),
  completedAt: z.date().nullable(),
  priority: z.enum(["low", "medium", "high"]).default("medium"),
  dueDate: z.date().nullable(),
}).transform((data) => ({
  ...data,
  completedAt: data.completedAt || undefined,
  dueDate: data.dueDate || undefined,
}));

export const insertTaskSchema = z.object({
  description: z.string().min(1, "Task description is required"),
  details: z.string().optional(),
  completed: z.boolean().default(false),
  priority: z.enum(["low", "medium", "high"]).default("medium"),
  dueDate: z.date().optional(),
});

export type Task = z.infer<typeof taskSchema>;
export type InsertTask = z.infer<typeof insertTaskSchema>;
