# Glass Tasks - Beautiful Task Management

## Overview

Glass Tasks is a modern task management application built with React and featuring a beautiful glassmorphism design. The application provides a Google Tasks-like experience with real-time synchronization via Firebase, an analog clock display, and calendar integration.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **Styling**: Glassmorphism design with custom CSS variables
- **Animation**: Framer Motion for smooth transitions
- **State Management**: React hooks with TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Server**: Express.js with TypeScript (ESM modules)
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Session-based with connect-pg-simple
- **API**: RESTful endpoints with proper error handling
- **Development**: Hot reload with Vite middleware integration

## Key Components

### Core Components
1. **Tasks Page** (`client/src/pages/Tasks.tsx`): Main task management interface
2. **TaskCard** (`client/src/components/TaskCard.tsx`): Individual task display with animations
3. **TaskStats** (`client/src/components/TaskStats.tsx`): Productivity metrics display
4. **Sidebar** (`client/src/components/Sidebar.tsx`): Navigation with clock and calendar
5. **AnalogClock** (`client/src/components/AnalogClock.tsx`): Real-time analog clock
6. **Calendar** (`client/src/components/Calendar.tsx`): Monthly calendar view

### Data Layer
- **Schema** (`shared/schema.ts`): Drizzle ORM schema with Zod validation
- **Database** (`server/db.ts`): PostgreSQL connection with Drizzle ORM
- **Storage Interface** (`server/storage.ts`): Database operations layer
- **API Routes** (`server/routes.ts`): RESTful endpoints for task management
- **Query Client** (`client/src/lib/queryClient.ts`): TanStack Query configuration

## Data Flow

### Task Management Flow
1. User creates task → Firebase Firestore collection
2. Real-time updates via Firebase listeners
3. Local state synchronized with server state
4. Optimistic updates for better UX

### Authentication Flow
- Session-based authentication (server-ready)
- PostgreSQL session store with connect-pg-simple
- Currently configured for development with memory storage

### Data Synchronization
- Firebase real-time listeners for live updates
- TanStack Query for caching and background updates
- Error handling with toast notifications

## External Dependencies

### Firebase Services
- **Firestore**: Primary database for task storage
- **Real-time Updates**: Live synchronization across clients
- **Configuration**: Environment-based Firebase config
- **Hosting**: Firebase hosting for static site deployment

### UI Libraries
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling
- **shadcn/ui**: Pre-built component library
- **Framer Motion**: Animation library
- **Lucide React**: Icon library

## Deployment Strategy

### Development Environment
- **Replit**: Configured for Node.js 20, Web, and PostgreSQL 16
- **Hot Reload**: Vite dev server with Express integration
- **Port Configuration**: Local port 5000, external port 80

### Production Build
- **Build Process**: 
  1. Vite builds client assets to `dist/public`
  2. esbuild bundles server code to `dist/index.js`
- **Deployment Target**: Autoscale deployment
- **Start Command**: `node dist/index.js`

### Environment Configuration
- **Database**: PostgreSQL via DATABASE_URL environment variable
- **Firebase**: Client-side configuration via environment variables
- **Development**: tsx for TypeScript execution
- **Production**: Compiled JavaScript execution

## Changelog

```
Changelog:
- June 21, 2025. Initial setup with Firebase integration
- June 21, 2025. Transformed to Focuspher with liquid glass design
- June 21, 2025. Added PostgreSQL database integration with Drizzle ORM
- June 21, 2025. Fixed sidebar button overlap and added task details functionality
- June 21, 2025. Migrated back to Firebase for database and hosting
- June 21, 2025. Fixed TaskCard component errors and completed Firebase integration
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
Database preference: Firebase for real-time features and hosting
UI requirements: Task details functionality, no overlapping elements
```