#!/usr/bin/env node

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

async function buildForFirebase() {
  console.log('Building for Firebase hosting...');
  
  try {
    // Build the client
    await new Promise((resolve, reject) => {
      exec('npm run build:client', (error, stdout, stderr) => {
        if (error) {
          console.error('Build error:', error);
          reject(error);
          return;
        }
        console.log(stdout);
        resolve();
      });
    });
    
    console.log('Build completed successfully!');
    console.log('Ready for Firebase deployment');
    
  } catch (error) {
    console.error('Build failed:', error);
    process.exit(1);
  }
}

buildForFirebase();