# Focuspher Task Manager - Local Setup

## Quick Start (5 minutes)

### 1. Prerequisites
- Install Node.js from https://nodejs.org (version 18+)

### 2. Install & Run
```bash
# In the project folder
npm install
npm run dev
```

### 3. Firebase Setup (Required)
1. Go to https://console.firebase.google.com
2. Create a new project
3. Enable Firestore Database
4. Copy your config from Project Settings > General
5. Replace the config in `client/src/lib/firebase.ts`

### 4. Firestore Rules (Important)
In Firebase Console > Firestore > Rules, paste:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

## App Features
- Responsive design for all devices
- Real-time task sync with Firebase
- Calendar scheduling
- Task details and priorities
- Progress tracking

## Need Help?
Check the full README.md for detailed instructions.

Your app will run at: http://localhost:5000