# Quick Setup Guide for Focuspher

## Step-by-Step Local Setup

### 1. Extract the ZIP file
Extract `focuspher-task-app.zip` to your desired location.

### 2. Open Terminal/Command Prompt
Navigate to the extracted folder:
```bash
cd focuspher-task-app
```

### 3. Install Node.js Dependencies
```bash
npm install
```

### 4. Update Firebase Configuration
Open `client/src/lib/firebase.ts` and replace the Firebase config with your own:

**Current config (replace this):**
```typescript
const firebaseConfig = {
  apiKey: "AIzaSyAb2FkQUyqZlK9nXSTRVGOIDC-r-oIPsgI",
  authDomain: "task-manager-4434d.firebaseapp.com",
  projectId: "task-manager-4434d",
  storageBucket: "task-manager-4434d.firebasestorage.app",
  messagingSenderId: "204062809009",
  appId: "1:204062809009:web:ef0ee1a43b24085d867b90"
};
```

**Replace with your Firebase config from Firebase Console.**

### 5. Set Up Firebase Firestore Rules
In your Firebase Console:
1. Go to Firestore Database
2. Go to Rules tab
3. Use this rule for development:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

### 6. Run the App
```bash
npm run dev
```

Open `http://localhost:5000` in your browser.

### 7. Test the App
- Add a few tasks
- Try the calendar functionality
- Test on different screen sizes
- Check mobile responsiveness

## Troubleshooting

**Issue: "npm: command not found"**
- Install Node.js from https://nodejs.org

**Issue: Firebase connection errors**
- Double-check your Firebase config
- Ensure Firestore is enabled in your Firebase project
- Check browser console for specific errors

**Issue: App not loading**
- Check if port 5000 is available
- Try `npm run dev -- --port 3000` to use a different port

## File Structure Overview
```
focuspher-task-app/
├── client/src/
│   ├── components/     # UI components
│   ├── hooks/         # React hooks
│   ├── lib/           # Firebase config here
│   └── pages/         # Main pages
├── server/            # Backend (optional)
├── package.json       # Dependencies
└── README.md          # Detailed documentation
```

That's it! Your task management app should now be running locally.